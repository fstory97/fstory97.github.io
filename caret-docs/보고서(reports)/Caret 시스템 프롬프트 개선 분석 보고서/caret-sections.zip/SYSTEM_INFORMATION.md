# SYSTEM INFORMATION

Operating System: {{osName}}
Default Shell: {{shell}}
Home Directory: {{homeDir}}
Current Working Directory: {{cwd}}
